﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Presentaion_Layer.ManageApplications.Detain_License
{
    public partial class RelaseLicenseForm : Form
    {
        public RelaseLicenseForm()
        {
            InitializeComponent();
        }

        private void GetTheDetainedLicense()
        {


        }

        private void RelaseLicenseForm_Load(object sender, EventArgs e)
        {

        }

        private void InitializeComponent()
        {
            this.SuspendLayout();
            // 
            // RelaseLicenseForm
            // 
            this.ClientSize = new System.Drawing.Size(807, 897);
            this.Name = "RelaseLicenseForm";
            this.Load += new System.EventHandler(this.RelaseLicenseForm_Load_1);
            this.ResumeLayout(false);

        }

        private void RelaseLicenseForm_Load_1(object sender, EventArgs e)
        {

        }
    }
}
