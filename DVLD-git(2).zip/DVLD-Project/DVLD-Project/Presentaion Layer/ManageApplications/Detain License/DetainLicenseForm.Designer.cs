﻿namespace Presentaion_Layer.ManageApplications.Detain_License
{
    partial class DetainLicenseForm
    {

        #region Windows Form Designer generated code

        #endregion
        private System.Windows.Forms.TextBox txtlicense;
        private Presentaion_Layer. ManageApplications.Licenses .Local_Licenses.Control.DriverLicenseControl driverLicenseControl1;
        private System.Windows.Forms.ListBox Filter;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.PictureBox pictureBox5;
        private System.Windows.Forms.PictureBox pictureBox6;
        private System.Windows.Forms.Button btnclose;
        private System.Windows.Forms.Button btnDetained;
        private Controls.DetainedControl detainedControl1;
    }
}