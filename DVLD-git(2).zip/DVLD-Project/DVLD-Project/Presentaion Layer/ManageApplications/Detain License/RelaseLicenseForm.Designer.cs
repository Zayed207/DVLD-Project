﻿namespace Presentaion_Layer.ManageApplications.Detain_License
{
    partial class RelaseLicenseForm
    {

        #region Windows Form Designer generated code

        #endregion
        private Presentaion_Layer.ManageApplications.Licenses.Local_Licenses.Control.DriverLicenseControl driverLicenseControl1;
        private System.Windows.Forms.TextBox txtLicense;
        private System.Windows.Forms.PictureBox pictureBox5;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.PictureBox pblicense;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Button btnClose;
        private System.Windows.Forms.Button btnrelase;
    }
}