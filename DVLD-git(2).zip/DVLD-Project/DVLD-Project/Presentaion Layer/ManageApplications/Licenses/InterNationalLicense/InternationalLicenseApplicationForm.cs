﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Presentaion_Layer.ManageApplications.Licenses.InterNationalLicense
{
    public partial class InternationalLicenseApplicationForm: Form
    {
        public InternationalLicenseApplicationForm()
        {
            InitializeComponent();
        }

        private void InternationalLicenseApplicationForm_Load(object sender, EventArgs e)
        {

        }
    }
}
