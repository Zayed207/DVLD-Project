﻿namespace Presentaion_Layer
{
    partial class Person
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnclose = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.lnkremove = new System.Windows.Forms.LinkLabel();
            this.lnksetimage = new System.Windows.Forms.LinkLabel();
            this.pbimage = new System.Windows.Forms.PictureBox();
            this.cmbcountry = new System.Windows.Forms.ComboBox();
            this.pictureBox9 = new System.Windows.Forms.PictureBox();
            this.pb = new System.Windows.Forms.PictureBox();
            this.pictureBox7 = new System.Windows.Forms.PictureBox();
            this.pictureBox6 = new System.Windows.Forms.PictureBox();
            this.pictureBox5 = new System.Windows.Forms.PictureBox();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.txtphone = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.lblc = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.txtaddress = new System.Windows.Forms.TextBox();
            this.rdfemele = new System.Windows.Forms.RadioButton();
            this.rdmale = new System.Windows.Forms.RadioButton();
            this.txtemail = new System.Windows.Forms.TextBox();
            this.txtnationalno = new System.Windows.Forms.TextBox();
            this.lbllast = new System.Windows.Forms.Label();
            this.lblthird = new System.Windows.Forms.Label();
            this.lblsec = new System.Windows.Forms.Label();
            this.lblfirst = new System.Windows.Forms.Label();
            this.txtlast = new System.Windows.Forms.TextBox();
            this.txtthird = new System.Windows.Forms.TextBox();
            this.txtsec = new System.Windows.Forms.TextBox();
            this.txtfirstname = new System.Windows.Forms.TextBox();
            this.lbladdress = new System.Windows.Forms.Label();
            this.lblemail = new System.Windows.Forms.Label();
            this.lblGender = new System.Windows.Forms.Label();
            this.lblNational = new System.Windows.Forms.Label();
            this.lblname = new System.Windows.Forms.Label();
            this.btnsave = new System.Windows.Forms.Button();
            this.lblPersonid = new System.Windows.Forms.Label();
            this.lbladdoredit = new System.Windows.Forms.Label();
            this.pictureBox12 = new System.Windows.Forms.PictureBox();
            this.pictureBox11 = new System.Windows.Forms.PictureBox();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbimage)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox9)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox12)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox11)).BeginInit();
            this.SuspendLayout();
            // 
            // btnclose
            // 
            this.btnclose.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnclose.Location = new System.Drawing.Point(600, 420);
            this.btnclose.Name = "btnclose";
            this.btnclose.Size = new System.Drawing.Size(97, 35);
            this.btnclose.TabIndex = 0;
            this.btnclose.Text = "Close";
            this.btnclose.UseVisualStyleBackColor = true;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Corbel", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(31, 60);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(90, 22);
            this.label1.TabIndex = 1;
            this.label1.Text = "Person ID :";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.dateTimePicker1);
            this.groupBox1.Controls.Add(this.lnkremove);
            this.groupBox1.Controls.Add(this.lnksetimage);
            this.groupBox1.Controls.Add(this.pbimage);
            this.groupBox1.Controls.Add(this.cmbcountry);
            this.groupBox1.Controls.Add(this.pictureBox9);
            this.groupBox1.Controls.Add(this.pb);
            this.groupBox1.Controls.Add(this.pictureBox7);
            this.groupBox1.Controls.Add(this.pictureBox6);
            this.groupBox1.Controls.Add(this.pictureBox5);
            this.groupBox1.Controls.Add(this.pictureBox4);
            this.groupBox1.Controls.Add(this.pictureBox3);
            this.groupBox1.Controls.Add(this.pictureBox2);
            this.groupBox1.Controls.Add(this.txtphone);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.lblc);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.txtaddress);
            this.groupBox1.Controls.Add(this.rdfemele);
            this.groupBox1.Controls.Add(this.rdmale);
            this.groupBox1.Controls.Add(this.txtemail);
            this.groupBox1.Controls.Add(this.txtnationalno);
            this.groupBox1.Controls.Add(this.lbllast);
            this.groupBox1.Controls.Add(this.lblthird);
            this.groupBox1.Controls.Add(this.lblsec);
            this.groupBox1.Controls.Add(this.lblfirst);
            this.groupBox1.Controls.Add(this.txtlast);
            this.groupBox1.Controls.Add(this.txtthird);
            this.groupBox1.Controls.Add(this.txtsec);
            this.groupBox1.Controls.Add(this.txtfirstname);
            this.groupBox1.Controls.Add(this.lbladdress);
            this.groupBox1.Controls.Add(this.lblemail);
            this.groupBox1.Controls.Add(this.lblGender);
            this.groupBox1.Controls.Add(this.lblNational);
            this.groupBox1.Controls.Add(this.lblname);
            this.groupBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.Location = new System.Drawing.Point(26, 85);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(856, 329);
            this.groupBox1.TabIndex = 4;
            this.groupBox1.TabStop = false;
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dateTimePicker1.Location = new System.Drawing.Point(514, 107);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new System.Drawing.Size(161, 28);
            this.dateTimePicker1.TabIndex = 34;
            // 
            // lnkremove
            // 
            this.lnkremove.AutoSize = true;
            this.lnkremove.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lnkremove.Location = new System.Drawing.Point(731, 284);
            this.lnkremove.Name = "lnkremove";
            this.lnkremove.Size = new System.Drawing.Size(64, 18);
            this.lnkremove.TabIndex = 33;
            this.lnkremove.TabStop = true;
            this.lnkremove.Text = "Remove";
            // 
            // lnksetimage
            // 
            this.lnksetimage.AutoSize = true;
            this.lnksetimage.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lnksetimage.Location = new System.Drawing.Point(703, 234);
            this.lnksetimage.Name = "lnksetimage";
            this.lnksetimage.Size = new System.Drawing.Size(70, 18);
            this.lnksetimage.TabIndex = 32;
            this.lnksetimage.TabStop = true;
            this.lnksetimage.Text = "SetImage";
            // 
            // pbimage
            // 
            this.pbimage.BackgroundImage = global::Presentaion_Layer.Properties.Resources.Male_512;
            this.pbimage.Image = global::Presentaion_Layer.Properties.Resources.Male_512;
            this.pbimage.Location = new System.Drawing.Point(688, 104);
            this.pbimage.Name = "pbimage";
            this.pbimage.Size = new System.Drawing.Size(150, 110);
            this.pbimage.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbimage.TabIndex = 6;
            this.pbimage.TabStop = false;
            // 
            // cmbcountry
            // 
            this.cmbcountry.FormattingEnabled = true;
            this.cmbcountry.Location = new System.Drawing.Point(514, 184);
            this.cmbcountry.Name = "cmbcountry";
            this.cmbcountry.Size = new System.Drawing.Size(161, 30);
            this.cmbcountry.TabIndex = 6;
            // 
            // pictureBox9
            // 
            this.pictureBox9.Image = global::Presentaion_Layer.Properties.Resources.Country_32;
            this.pictureBox9.Location = new System.Drawing.Point(469, 192);
            this.pictureBox9.Name = "pictureBox9";
            this.pictureBox9.Size = new System.Drawing.Size(30, 22);
            this.pictureBox9.TabIndex = 31;
            this.pictureBox9.TabStop = false;
            // 
            // pb
            // 
            this.pb.Image = global::Presentaion_Layer.Properties.Resources.Phone_32;
            this.pb.Location = new System.Drawing.Point(469, 147);
            this.pb.Name = "pb";
            this.pb.Size = new System.Drawing.Size(30, 22);
            this.pb.TabIndex = 30;
            this.pb.TabStop = false;
            // 
            // pictureBox7
            // 
            this.pictureBox7.Image = global::Presentaion_Layer.Properties.Resources.Calendar_32;
            this.pictureBox7.Location = new System.Drawing.Point(469, 110);
            this.pictureBox7.Name = "pictureBox7";
            this.pictureBox7.Size = new System.Drawing.Size(30, 22);
            this.pictureBox7.TabIndex = 29;
            this.pictureBox7.TabStop = false;
            // 
            // pictureBox6
            // 
            this.pictureBox6.Image = global::Presentaion_Layer.Properties.Resources.Address_321;
            this.pictureBox6.Location = new System.Drawing.Point(129, 229);
            this.pictureBox6.Name = "pictureBox6";
            this.pictureBox6.Size = new System.Drawing.Size(30, 22);
            this.pictureBox6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox6.TabIndex = 28;
            this.pictureBox6.TabStop = false;
            // 
            // pictureBox5
            // 
            this.pictureBox5.Image = global::Presentaion_Layer.Properties.Resources.Email_32;
            this.pictureBox5.Location = new System.Drawing.Point(129, 190);
            this.pictureBox5.Name = "pictureBox5";
            this.pictureBox5.Size = new System.Drawing.Size(30, 22);
            this.pictureBox5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox5.TabIndex = 27;
            this.pictureBox5.TabStop = false;
            // 
            // pictureBox4
            // 
            this.pictureBox4.Image = global::Presentaion_Layer.Properties.Resources.Person_32;
            this.pictureBox4.Location = new System.Drawing.Point(129, 144);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(30, 22);
            this.pictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox4.TabIndex = 26;
            this.pictureBox4.TabStop = false;
            // 
            // pictureBox3
            // 
            this.pictureBox3.Image = global::Presentaion_Layer.Properties.Resources.Application_Types_64;
            this.pictureBox3.Location = new System.Drawing.Point(129, 103);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(30, 22);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox3.TabIndex = 25;
            this.pictureBox3.TabStop = false;
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = global::Presentaion_Layer.Properties.Resources.Person_323;
            this.pictureBox2.Location = new System.Drawing.Point(129, 61);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(30, 22);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 6;
            this.pictureBox2.TabStop = false;
            // 
            // txtphone
            // 
            this.txtphone.Location = new System.Drawing.Point(514, 141);
            this.txtphone.Name = "txtphone";
            this.txtphone.Size = new System.Drawing.Size(161, 28);
            this.txtphone.TabIndex = 23;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(334, 110);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(119, 22);
            this.label4.TabIndex = 21;
            this.label4.Text = "Date Of  Birth";
            // 
            // lblc
            // 
            this.lblc.AutoSize = true;
            this.lblc.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblc.Location = new System.Drawing.Point(334, 187);
            this.lblc.Name = "lblc";
            this.lblc.Size = new System.Drawing.Size(73, 22);
            this.lblc.TabIndex = 20;
            this.lblc.Text = "Country";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(334, 147);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(62, 22);
            this.label2.TabIndex = 19;
            this.label2.Text = "Phone";
            // 
            // txtaddress
            // 
            this.txtaddress.Location = new System.Drawing.Point(165, 229);
            this.txtaddress.Multiline = true;
            this.txtaddress.Name = "txtaddress";
            this.txtaddress.Size = new System.Drawing.Size(510, 94);
            this.txtaddress.TabIndex = 18;
            // 
            // rdfemele
            // 
            this.rdfemele.AutoSize = true;
            this.rdfemele.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rdfemele.Location = new System.Drawing.Point(250, 147);
            this.rdfemele.Name = "rdfemele";
            this.rdfemele.Size = new System.Drawing.Size(78, 22);
            this.rdfemele.TabIndex = 17;
            this.rdfemele.TabStop = true;
            this.rdfemele.Text = "Femele";
            this.rdfemele.UseVisualStyleBackColor = true;
            // 
            // rdmale
            // 
            this.rdmale.AutoSize = true;
            this.rdmale.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rdmale.Location = new System.Drawing.Point(171, 147);
            this.rdmale.Name = "rdmale";
            this.rdmale.Size = new System.Drawing.Size(61, 22);
            this.rdmale.TabIndex = 16;
            this.rdmale.TabStop = true;
            this.rdmale.Text = "Male";
            this.rdmale.UseVisualStyleBackColor = true;
            // 
            // txtemail
            // 
            this.txtemail.Location = new System.Drawing.Point(165, 184);
            this.txtemail.Name = "txtemail";
            this.txtemail.Size = new System.Drawing.Size(136, 28);
            this.txtemail.TabIndex = 15;
            // 
            // txtnationalno
            // 
            this.txtnationalno.Location = new System.Drawing.Point(165, 98);
            this.txtnationalno.Name = "txtnationalno";
            this.txtnationalno.Size = new System.Drawing.Size(136, 28);
            this.txtnationalno.TabIndex = 14;
            this.txtnationalno.TextChanged += new System.EventHandler(this.txtnationalno_TextChanged);
            // 
            // lbllast
            // 
            this.lbllast.AutoSize = true;
            this.lbllast.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbllast.Location = new System.Drawing.Point(728, 18);
            this.lbllast.Name = "lbllast";
            this.lbllast.Size = new System.Drawing.Size(44, 22);
            this.lbllast.TabIndex = 13;
            this.lbllast.Text = "Last";
            // 
            // lblthird
            // 
            this.lblthird.AutoSize = true;
            this.lblthird.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblthird.Location = new System.Drawing.Point(552, 18);
            this.lblthird.Name = "lblthird";
            this.lblthird.Size = new System.Drawing.Size(52, 22);
            this.lblthird.TabIndex = 12;
            this.lblthird.Text = "Third";
            // 
            // lblsec
            // 
            this.lblsec.AutoSize = true;
            this.lblsec.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblsec.Location = new System.Drawing.Point(350, 18);
            this.lblsec.Name = "lblsec";
            this.lblsec.Size = new System.Drawing.Size(71, 22);
            this.lblsec.TabIndex = 11;
            this.lblsec.Text = "Second";
            // 
            // lblfirst
            // 
            this.lblfirst.AutoSize = true;
            this.lblfirst.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblfirst.Location = new System.Drawing.Point(202, 18);
            this.lblfirst.Name = "lblfirst";
            this.lblfirst.Size = new System.Drawing.Size(45, 22);
            this.lblfirst.TabIndex = 10;
            this.lblfirst.Text = "First";
            // 
            // txtlast
            // 
            this.txtlast.Location = new System.Drawing.Point(688, 55);
            this.txtlast.Name = "txtlast";
            this.txtlast.Size = new System.Drawing.Size(134, 28);
            this.txtlast.TabIndex = 9;
            // 
            // txtthird
            // 
            this.txtthird.Location = new System.Drawing.Point(514, 55);
            this.txtthird.Name = "txtthird";
            this.txtthird.Size = new System.Drawing.Size(134, 28);
            this.txtthird.TabIndex = 6;
            // 
            // txtsec
            // 
            this.txtsec.Location = new System.Drawing.Point(329, 55);
            this.txtsec.Name = "txtsec";
            this.txtsec.Size = new System.Drawing.Size(159, 28);
            this.txtsec.TabIndex = 7;
            // 
            // txtfirstname
            // 
            this.txtfirstname.Location = new System.Drawing.Point(165, 55);
            this.txtfirstname.Name = "txtfirstname";
            this.txtfirstname.Size = new System.Drawing.Size(136, 28);
            this.txtfirstname.TabIndex = 8;
            // 
            // lbladdress
            // 
            this.lbladdress.AutoSize = true;
            this.lbladdress.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbladdress.Location = new System.Drawing.Point(19, 229);
            this.lbladdress.Name = "lbladdress";
            this.lbladdress.Size = new System.Drawing.Size(76, 22);
            this.lbladdress.TabIndex = 6;
            this.lbladdress.Text = "Address";
            // 
            // lblemail
            // 
            this.lblemail.AutoSize = true;
            this.lblemail.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblemail.Location = new System.Drawing.Point(19, 184);
            this.lblemail.Name = "lblemail";
            this.lblemail.Size = new System.Drawing.Size(54, 22);
            this.lblemail.TabIndex = 5;
            this.lblemail.Text = "Email";
            // 
            // lblGender
            // 
            this.lblGender.AutoSize = true;
            this.lblGender.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblGender.Location = new System.Drawing.Point(19, 143);
            this.lblGender.Name = "lblGender";
            this.lblGender.Size = new System.Drawing.Size(70, 22);
            this.lblGender.TabIndex = 4;
            this.lblGender.Text = "Gender";
            // 
            // lblNational
            // 
            this.lblNational.AutoSize = true;
            this.lblNational.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNational.Location = new System.Drawing.Point(14, 98);
            this.lblNational.Name = "lblNational";
            this.lblNational.Size = new System.Drawing.Size(104, 22);
            this.lblNational.TabIndex = 3;
            this.lblNational.Text = "National No";
            // 
            // lblname
            // 
            this.lblname.AutoSize = true;
            this.lblname.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblname.Location = new System.Drawing.Point(19, 55);
            this.lblname.Name = "lblname";
            this.lblname.Size = new System.Drawing.Size(57, 22);
            this.lblname.TabIndex = 2;
            this.lblname.Text = "Name";
            // 
            // btnsave
            // 
            this.btnsave.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnsave.Location = new System.Drawing.Point(766, 420);
            this.btnsave.Name = "btnsave";
            this.btnsave.Size = new System.Drawing.Size(98, 35);
            this.btnsave.TabIndex = 6;
            this.btnsave.Text = "Save";
            this.btnsave.UseVisualStyleBackColor = true;
            this.btnsave.Click += new System.EventHandler(this.btnsave_Click);
            // 
            // lblPersonid
            // 
            this.lblPersonid.AutoSize = true;
            this.lblPersonid.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPersonid.Location = new System.Drawing.Point(151, 62);
            this.lblPersonid.Name = "lblPersonid";
            this.lblPersonid.Size = new System.Drawing.Size(37, 20);
            this.lblPersonid.TabIndex = 7;
            this.lblPersonid.Text = "N\\A";
            this.lblPersonid.Click += new System.EventHandler(this.lblPersonid_Click);
            // 
            // lbladdoredit
            // 
            this.lbladdoredit.AutoSize = true;
            this.lbladdoredit.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbladdoredit.ForeColor = System.Drawing.Color.ForestGreen;
            this.lbladdoredit.Location = new System.Drawing.Point(301, 9);
            this.lbladdoredit.Name = "lbladdoredit";
            this.lbladdoredit.Size = new System.Drawing.Size(320, 46);
            this.lbladdoredit.TabIndex = 8;
            this.lbladdoredit.Text = "Add New Person";
            // 
            // pictureBox12
            // 
            this.pictureBox12.Image = global::Presentaion_Layer.Properties.Resources.Save_32;
            this.pictureBox12.Location = new System.Drawing.Point(732, 420);
            this.pictureBox12.Name = "pictureBox12";
            this.pictureBox12.Size = new System.Drawing.Size(30, 35);
            this.pictureBox12.TabIndex = 34;
            this.pictureBox12.TabStop = false;
            // 
            // pictureBox11
            // 
            this.pictureBox11.Image = global::Presentaion_Layer.Properties.Resources.Close_32;
            this.pictureBox11.Location = new System.Drawing.Point(573, 420);
            this.pictureBox11.Name = "pictureBox11";
            this.pictureBox11.Size = new System.Drawing.Size(30, 35);
            this.pictureBox11.TabIndex = 33;
            this.pictureBox11.TabStop = false;
            // 
            // Person
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.pictureBox12);
            this.Controls.Add(this.pictureBox11);
            this.Controls.Add(this.lbladdoredit);
            this.Controls.Add(this.lblPersonid);
            this.Controls.Add(this.btnsave);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.btnclose);
            this.Name = "Person";
            this.Size = new System.Drawing.Size(890, 469);
            this.Load += new System.EventHandler(this.Person_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbimage)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox9)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox12)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox11)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Button btnclose;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TextBox txtlast;
        private System.Windows.Forms.TextBox txtthird;
        private System.Windows.Forms.TextBox txtsec;
        private System.Windows.Forms.TextBox txtfirstname;
        private System.Windows.Forms.Label lbladdress;
        private System.Windows.Forms.Label lblemail;
        private System.Windows.Forms.Label lblNational;
        private System.Windows.Forms.Label lblname;
        private System.Windows.Forms.Label lbllast;
        private System.Windows.Forms.Label lblthird;
        private System.Windows.Forms.Label lblsec;
        private System.Windows.Forms.Label lblfirst;
        private System.Windows.Forms.Label lblGender;
        private System.Windows.Forms.TextBox txtemail;
        private System.Windows.Forms.TextBox txtnationalno;
        private System.Windows.Forms.TextBox txtaddress;
        private System.Windows.Forms.RadioButton rdfemele;
        private System.Windows.Forms.RadioButton rdmale;
        private System.Windows.Forms.ComboBox cmbcountry;
        private System.Windows.Forms.PictureBox pictureBox9;
        private System.Windows.Forms.PictureBox pb;
        private System.Windows.Forms.PictureBox pictureBox7;
        private System.Windows.Forms.PictureBox pictureBox6;
        private System.Windows.Forms.PictureBox pictureBox5;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.TextBox txtphone;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label lblc;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.PictureBox pbimage;
        private System.Windows.Forms.Button btnsave;
        private System.Windows.Forms.Label lblPersonid;
        private System.Windows.Forms.Label lbladdoredit;
        private System.Windows.Forms.PictureBox pictureBox11;
        private System.Windows.Forms.PictureBox pictureBox12;
        private System.Windows.Forms.LinkLabel lnkremove;
        private System.Windows.Forms.LinkLabel lnksetimage;
        private System.Windows.Forms.DateTimePicker dateTimePicker1;
    }
}
