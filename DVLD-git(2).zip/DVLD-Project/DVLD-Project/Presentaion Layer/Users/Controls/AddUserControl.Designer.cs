﻿namespace Presentaion_Layer.Users.Controls
{
    partial class AddUserControl
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.pbimage = new System.Windows.Forms.PictureBox();
            this.cmbcountry = new System.Windows.Forms.ComboBox();
            this.pictureBox9 = new System.Windows.Forms.PictureBox();
            this.pb = new System.Windows.Forms.PictureBox();
            this.pictureBox7 = new System.Windows.Forms.PictureBox();
            this.pictureBox6 = new System.Windows.Forms.PictureBox();
            this.pictureBox5 = new System.Windows.Forms.PictureBox();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.txtphone = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.lblc = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.txtaddress = new System.Windows.Forms.TextBox();
            this.rdfemele = new System.Windows.Forms.RadioButton();
            this.rdmale = new System.Windows.Forms.RadioButton();
            this.txtemail = new System.Windows.Forms.TextBox();
            this.txtnationalno = new System.Windows.Forms.TextBox();
            this.lbllast = new System.Windows.Forms.Label();
            this.lblthird = new System.Windows.Forms.Label();
            this.lblsec = new System.Windows.Forms.Label();
            this.lblfirst = new System.Windows.Forms.Label();
            this.txtlast = new System.Windows.Forms.TextBox();
            this.txtthird = new System.Windows.Forms.TextBox();
            this.txtsec = new System.Windows.Forms.TextBox();
            this.txtfirstname = new System.Windows.Forms.TextBox();
            this.lbladdress = new System.Windows.Forms.Label();
            this.lblemail = new System.Windows.Forms.Label();
            this.lblGender = new System.Windows.Forms.Label();
            this.lblNational = new System.Windows.Forms.Label();
            this.lblname = new System.Windows.Forms.Label();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tppersonal = new System.Windows.Forms.TabPage();
            this.pictureBox12 = new System.Windows.Forms.PictureBox();
            this.btnnext = new System.Windows.Forms.Button();
            this.gb = new System.Windows.Forms.GroupBox();
            this.pictureBox8 = new System.Windows.Forms.PictureBox();
            this.cmbfiltr = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.txtfilter = new System.Windows.Forms.TextBox();
            this.tplogin = new System.Windows.Forms.TabPage();
            this.pictureBox17 = new System.Windows.Forms.PictureBox();
            this.pictureBox16 = new System.Windows.Forms.PictureBox();
            this.pictureBox15 = new System.Windows.Forms.PictureBox();
            this.pictureBox13 = new System.Windows.Forms.PictureBox();
            this.cbisactive = new System.Windows.Forms.CheckBox();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.txtuserpassword = new System.Windows.Forms.TextBox();
            this.txtconfirmuserpassword = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.lbluserid = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.txtusername = new System.Windows.Forms.TextBox();
            this.btnsave = new System.Windows.Forms.Button();
            this.btnclose = new System.Windows.Forms.Button();
            this.pictureBox11 = new System.Windows.Forms.PictureBox();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbimage)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox9)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.tabControl1.SuspendLayout();
            this.tppersonal.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox12)).BeginInit();
            this.gb.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.tplogin.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox17)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox16)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox15)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox13)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox11)).BeginInit();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.dateTimePicker1);
            this.groupBox1.Controls.Add(this.pbimage);
            this.groupBox1.Controls.Add(this.cmbcountry);
            this.groupBox1.Controls.Add(this.pictureBox9);
            this.groupBox1.Controls.Add(this.pb);
            this.groupBox1.Controls.Add(this.pictureBox7);
            this.groupBox1.Controls.Add(this.pictureBox6);
            this.groupBox1.Controls.Add(this.pictureBox5);
            this.groupBox1.Controls.Add(this.pictureBox4);
            this.groupBox1.Controls.Add(this.pictureBox3);
            this.groupBox1.Controls.Add(this.pictureBox2);
            this.groupBox1.Controls.Add(this.txtphone);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.lblc);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.txtaddress);
            this.groupBox1.Controls.Add(this.rdfemele);
            this.groupBox1.Controls.Add(this.rdmale);
            this.groupBox1.Controls.Add(this.txtemail);
            this.groupBox1.Controls.Add(this.txtnationalno);
            this.groupBox1.Controls.Add(this.lbllast);
            this.groupBox1.Controls.Add(this.lblthird);
            this.groupBox1.Controls.Add(this.lblsec);
            this.groupBox1.Controls.Add(this.lblfirst);
            this.groupBox1.Controls.Add(this.txtlast);
            this.groupBox1.Controls.Add(this.txtthird);
            this.groupBox1.Controls.Add(this.txtsec);
            this.groupBox1.Controls.Add(this.txtfirstname);
            this.groupBox1.Controls.Add(this.lbladdress);
            this.groupBox1.Controls.Add(this.lblemail);
            this.groupBox1.Controls.Add(this.lblGender);
            this.groupBox1.Controls.Add(this.lblNational);
            this.groupBox1.Controls.Add(this.lblname);
            this.groupBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.Location = new System.Drawing.Point(6, 127);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(843, 298);
            this.groupBox1.TabIndex = 5;
            this.groupBox1.TabStop = false;
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dateTimePicker1.Location = new System.Drawing.Point(514, 107);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new System.Drawing.Size(161, 28);
            this.dateTimePicker1.TabIndex = 34;
            // 
            // pbimage
            // 
            this.pbimage.BackgroundImage = global::Presentaion_Layer.Properties.Resources.Male_512;
            this.pbimage.Image = global::Presentaion_Layer.Properties.Resources.Male_512;
            this.pbimage.Location = new System.Drawing.Point(688, 104);
            this.pbimage.Name = "pbimage";
            this.pbimage.Size = new System.Drawing.Size(150, 110);
            this.pbimage.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbimage.TabIndex = 6;
            this.pbimage.TabStop = false;
            // 
            // cmbcountry
            // 
            this.cmbcountry.FormattingEnabled = true;
            this.cmbcountry.Location = new System.Drawing.Point(514, 184);
            this.cmbcountry.Name = "cmbcountry";
            this.cmbcountry.Size = new System.Drawing.Size(161, 30);
            this.cmbcountry.TabIndex = 6;
            // 
            // pictureBox9
            // 
            this.pictureBox9.Image = global::Presentaion_Layer.Properties.Resources.Country_32;
            this.pictureBox9.Location = new System.Drawing.Point(469, 192);
            this.pictureBox9.Name = "pictureBox9";
            this.pictureBox9.Size = new System.Drawing.Size(30, 22);
            this.pictureBox9.TabIndex = 31;
            this.pictureBox9.TabStop = false;
            // 
            // pb
            // 
            this.pb.Image = global::Presentaion_Layer.Properties.Resources.Phone_32;
            this.pb.Location = new System.Drawing.Point(469, 147);
            this.pb.Name = "pb";
            this.pb.Size = new System.Drawing.Size(30, 22);
            this.pb.TabIndex = 30;
            this.pb.TabStop = false;
            // 
            // pictureBox7
            // 
            this.pictureBox7.Image = global::Presentaion_Layer.Properties.Resources.Calendar_32;
            this.pictureBox7.Location = new System.Drawing.Point(469, 110);
            this.pictureBox7.Name = "pictureBox7";
            this.pictureBox7.Size = new System.Drawing.Size(30, 22);
            this.pictureBox7.TabIndex = 29;
            this.pictureBox7.TabStop = false;
            // 
            // pictureBox6
            // 
            this.pictureBox6.Image = global::Presentaion_Layer.Properties.Resources.Address_321;
            this.pictureBox6.Location = new System.Drawing.Point(129, 229);
            this.pictureBox6.Name = "pictureBox6";
            this.pictureBox6.Size = new System.Drawing.Size(30, 22);
            this.pictureBox6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox6.TabIndex = 28;
            this.pictureBox6.TabStop = false;
            // 
            // pictureBox5
            // 
            this.pictureBox5.Image = global::Presentaion_Layer.Properties.Resources.Email_32;
            this.pictureBox5.Location = new System.Drawing.Point(129, 190);
            this.pictureBox5.Name = "pictureBox5";
            this.pictureBox5.Size = new System.Drawing.Size(30, 22);
            this.pictureBox5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox5.TabIndex = 27;
            this.pictureBox5.TabStop = false;
            // 
            // pictureBox4
            // 
            this.pictureBox4.Image = global::Presentaion_Layer.Properties.Resources.Person_32;
            this.pictureBox4.Location = new System.Drawing.Point(129, 144);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(30, 22);
            this.pictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox4.TabIndex = 26;
            this.pictureBox4.TabStop = false;
            // 
            // pictureBox3
            // 
            this.pictureBox3.Image = global::Presentaion_Layer.Properties.Resources.Application_Types_64;
            this.pictureBox3.Location = new System.Drawing.Point(129, 103);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(30, 22);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox3.TabIndex = 25;
            this.pictureBox3.TabStop = false;
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = global::Presentaion_Layer.Properties.Resources.Person_323;
            this.pictureBox2.Location = new System.Drawing.Point(129, 61);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(30, 22);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 6;
            this.pictureBox2.TabStop = false;
            // 
            // txtphone
            // 
            this.txtphone.Location = new System.Drawing.Point(514, 141);
            this.txtphone.Name = "txtphone";
            this.txtphone.Size = new System.Drawing.Size(161, 28);
            this.txtphone.TabIndex = 23;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(334, 110);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(119, 22);
            this.label4.TabIndex = 21;
            this.label4.Text = "Date Of  Birth";
            // 
            // lblc
            // 
            this.lblc.AutoSize = true;
            this.lblc.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblc.Location = new System.Drawing.Point(334, 187);
            this.lblc.Name = "lblc";
            this.lblc.Size = new System.Drawing.Size(73, 22);
            this.lblc.TabIndex = 20;
            this.lblc.Text = "Country";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(334, 147);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(62, 22);
            this.label2.TabIndex = 19;
            this.label2.Text = "Phone";
            // 
            // txtaddress
            // 
            this.txtaddress.Location = new System.Drawing.Point(165, 229);
            this.txtaddress.Multiline = true;
            this.txtaddress.Name = "txtaddress";
            this.txtaddress.Size = new System.Drawing.Size(510, 94);
            this.txtaddress.TabIndex = 18;
            // 
            // rdfemele
            // 
            this.rdfemele.AutoSize = true;
            this.rdfemele.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rdfemele.Location = new System.Drawing.Point(250, 147);
            this.rdfemele.Name = "rdfemele";
            this.rdfemele.Size = new System.Drawing.Size(78, 22);
            this.rdfemele.TabIndex = 17;
            this.rdfemele.TabStop = true;
            this.rdfemele.Text = "Femele";
            this.rdfemele.UseVisualStyleBackColor = true;
            // 
            // rdmale
            // 
            this.rdmale.AutoSize = true;
            this.rdmale.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rdmale.Location = new System.Drawing.Point(171, 147);
            this.rdmale.Name = "rdmale";
            this.rdmale.Size = new System.Drawing.Size(61, 22);
            this.rdmale.TabIndex = 16;
            this.rdmale.TabStop = true;
            this.rdmale.Text = "Male";
            this.rdmale.UseVisualStyleBackColor = true;
            // 
            // txtemail
            // 
            this.txtemail.Location = new System.Drawing.Point(165, 184);
            this.txtemail.Name = "txtemail";
            this.txtemail.Size = new System.Drawing.Size(136, 28);
            this.txtemail.TabIndex = 15;
            // 
            // txtnationalno
            // 
            this.txtnationalno.Location = new System.Drawing.Point(165, 98);
            this.txtnationalno.Name = "txtnationalno";
            this.txtnationalno.Size = new System.Drawing.Size(136, 28);
            this.txtnationalno.TabIndex = 14;
            // 
            // lbllast
            // 
            this.lbllast.AutoSize = true;
            this.lbllast.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbllast.Location = new System.Drawing.Point(728, 18);
            this.lbllast.Name = "lbllast";
            this.lbllast.Size = new System.Drawing.Size(44, 22);
            this.lbllast.TabIndex = 13;
            this.lbllast.Text = "Last";
            // 
            // lblthird
            // 
            this.lblthird.AutoSize = true;
            this.lblthird.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblthird.Location = new System.Drawing.Point(552, 18);
            this.lblthird.Name = "lblthird";
            this.lblthird.Size = new System.Drawing.Size(52, 22);
            this.lblthird.TabIndex = 12;
            this.lblthird.Text = "Third";
            // 
            // lblsec
            // 
            this.lblsec.AutoSize = true;
            this.lblsec.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblsec.Location = new System.Drawing.Point(336, 18);
            this.lblsec.Name = "lblsec";
            this.lblsec.Size = new System.Drawing.Size(71, 22);
            this.lblsec.TabIndex = 11;
            this.lblsec.Text = "Second";
            // 
            // lblfirst
            // 
            this.lblfirst.AutoSize = true;
            this.lblfirst.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblfirst.Location = new System.Drawing.Point(202, 18);
            this.lblfirst.Name = "lblfirst";
            this.lblfirst.Size = new System.Drawing.Size(45, 22);
            this.lblfirst.TabIndex = 10;
            this.lblfirst.Text = "First";
            // 
            // txtlast
            // 
            this.txtlast.Location = new System.Drawing.Point(688, 55);
            this.txtlast.Name = "txtlast";
            this.txtlast.Size = new System.Drawing.Size(134, 28);
            this.txtlast.TabIndex = 9;
            // 
            // txtthird
            // 
            this.txtthird.Location = new System.Drawing.Point(514, 55);
            this.txtthird.Name = "txtthird";
            this.txtthird.Size = new System.Drawing.Size(134, 28);
            this.txtthird.TabIndex = 6;
            // 
            // txtsec
            // 
            this.txtsec.Location = new System.Drawing.Point(329, 55);
            this.txtsec.Name = "txtsec";
            this.txtsec.Size = new System.Drawing.Size(159, 28);
            this.txtsec.TabIndex = 7;
            // 
            // txtfirstname
            // 
            this.txtfirstname.Location = new System.Drawing.Point(165, 55);
            this.txtfirstname.Name = "txtfirstname";
            this.txtfirstname.Size = new System.Drawing.Size(136, 28);
            this.txtfirstname.TabIndex = 8;
            // 
            // lbladdress
            // 
            this.lbladdress.AutoSize = true;
            this.lbladdress.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbladdress.Location = new System.Drawing.Point(19, 229);
            this.lbladdress.Name = "lbladdress";
            this.lbladdress.Size = new System.Drawing.Size(76, 22);
            this.lbladdress.TabIndex = 6;
            this.lbladdress.Text = "Address";
            // 
            // lblemail
            // 
            this.lblemail.AutoSize = true;
            this.lblemail.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblemail.Location = new System.Drawing.Point(19, 184);
            this.lblemail.Name = "lblemail";
            this.lblemail.Size = new System.Drawing.Size(54, 22);
            this.lblemail.TabIndex = 5;
            this.lblemail.Text = "Email";
            // 
            // lblGender
            // 
            this.lblGender.AutoSize = true;
            this.lblGender.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblGender.Location = new System.Drawing.Point(19, 143);
            this.lblGender.Name = "lblGender";
            this.lblGender.Size = new System.Drawing.Size(70, 22);
            this.lblGender.TabIndex = 4;
            this.lblGender.Text = "Gender";
            // 
            // lblNational
            // 
            this.lblNational.AutoSize = true;
            this.lblNational.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNational.Location = new System.Drawing.Point(14, 98);
            this.lblNational.Name = "lblNational";
            this.lblNational.Size = new System.Drawing.Size(104, 22);
            this.lblNational.TabIndex = 3;
            this.lblNational.Text = "National No";
            // 
            // lblname
            // 
            this.lblname.AutoSize = true;
            this.lblname.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblname.Location = new System.Drawing.Point(19, 55);
            this.lblname.Name = "lblname";
            this.lblname.Size = new System.Drawing.Size(57, 22);
            this.lblname.TabIndex = 2;
            this.lblname.Text = "Name";
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tppersonal);
            this.tabControl1.Controls.Add(this.tplogin);
            this.tabControl1.Location = new System.Drawing.Point(12, 88);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(875, 512);
            this.tabControl1.TabIndex = 0;
            // 
            // tppersonal
            // 
            this.tppersonal.Controls.Add(this.pictureBox12);
            this.tppersonal.Controls.Add(this.btnnext);
            this.tppersonal.Controls.Add(this.gb);
            this.tppersonal.Controls.Add(this.groupBox1);
            this.tppersonal.Location = new System.Drawing.Point(4, 25);
            this.tppersonal.Name = "tppersonal";
            this.tppersonal.Padding = new System.Windows.Forms.Padding(3);
            this.tppersonal.Size = new System.Drawing.Size(867, 483);
            this.tppersonal.TabIndex = 0;
            this.tppersonal.Text = "Personal Info";
            this.tppersonal.UseVisualStyleBackColor = true;
            this.tppersonal.Click += new System.EventHandler(this.tabPage1_Click);
            // 
            // pictureBox12
            // 
            this.pictureBox12.Image = global::Presentaion_Layer.Properties.Resources.Next_32;
            this.pictureBox12.Location = new System.Drawing.Point(694, 431);
            this.pictureBox12.Name = "pictureBox12";
            this.pictureBox12.Size = new System.Drawing.Size(29, 29);
            this.pictureBox12.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox12.TabIndex = 7;
            this.pictureBox12.TabStop = false;
            // 
            // btnnext
            // 
            this.btnnext.Location = new System.Drawing.Point(720, 431);
            this.btnnext.Name = "btnnext";
            this.btnnext.Size = new System.Drawing.Size(129, 29);
            this.btnnext.TabIndex = 8;
            this.btnnext.Text = "Next";
            this.btnnext.UseVisualStyleBackColor = true;
            this.btnnext.Click += new System.EventHandler(this.btnnext_Click);
            // 
            // gb
            // 
            this.gb.Controls.Add(this.pictureBox8);
            this.gb.Controls.Add(this.cmbfiltr);
            this.gb.Controls.Add(this.label1);
            this.gb.Controls.Add(this.pictureBox1);
            this.gb.Controls.Add(this.txtfilter);
            this.gb.Location = new System.Drawing.Point(6, 38);
            this.gb.Name = "gb";
            this.gb.Size = new System.Drawing.Size(855, 83);
            this.gb.TabIndex = 6;
            this.gb.TabStop = false;
            this.gb.Text = " ";
            // 
            // pictureBox8
            // 
            this.pictureBox8.Image = global::Presentaion_Layer.Properties.Resources.Add_Person_40;
            this.pictureBox8.Location = new System.Drawing.Point(620, 34);
            this.pictureBox8.Name = "pictureBox8";
            this.pictureBox8.Size = new System.Drawing.Size(28, 32);
            this.pictureBox8.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox8.TabIndex = 4;
            this.pictureBox8.TabStop = false;
            this.pictureBox8.Click += new System.EventHandler(this.pictureBox8_Click);
            // 
            // cmbfiltr
            // 
            this.cmbfiltr.FormattingEnabled = true;
            this.cmbfiltr.Items.AddRange(new object[] {
            "NationalNo",
            "PersonID"});
            this.cmbfiltr.Location = new System.Drawing.Point(126, 42);
            this.cmbfiltr.Name = "cmbfiltr";
            this.cmbfiltr.Size = new System.Drawing.Size(121, 24);
            this.cmbfiltr.TabIndex = 3;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(19, 42);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(76, 22);
            this.label1.TabIndex = 2;
            this.label1.Text = "Filter By";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::Presentaion_Layer.Properties.Resources.SearchPerson;
            this.pictureBox1.Location = new System.Drawing.Point(576, 34);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(28, 32);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 1;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // txtfilter
            // 
            this.txtfilter.Location = new System.Drawing.Point(285, 44);
            this.txtfilter.Name = "txtfilter";
            this.txtfilter.Size = new System.Drawing.Size(244, 22);
            this.txtfilter.TabIndex = 0;
            // 
            // tplogin
            // 
            this.tplogin.Controls.Add(this.pictureBox17);
            this.tplogin.Controls.Add(this.pictureBox16);
            this.tplogin.Controls.Add(this.pictureBox15);
            this.tplogin.Controls.Add(this.pictureBox13);
            this.tplogin.Controls.Add(this.cbisactive);
            this.tplogin.Controls.Add(this.label9);
            this.tplogin.Controls.Add(this.label8);
            this.tplogin.Controls.Add(this.txtuserpassword);
            this.tplogin.Controls.Add(this.txtconfirmuserpassword);
            this.tplogin.Controls.Add(this.label7);
            this.tplogin.Controls.Add(this.lbluserid);
            this.tplogin.Controls.Add(this.label3);
            this.tplogin.Controls.Add(this.txtusername);
            this.tplogin.Location = new System.Drawing.Point(4, 25);
            this.tplogin.Name = "tplogin";
            this.tplogin.Padding = new System.Windows.Forms.Padding(3);
            this.tplogin.Size = new System.Drawing.Size(867, 483);
            this.tplogin.TabIndex = 1;
            this.tplogin.Text = "LoginInfo";
            this.tplogin.UseVisualStyleBackColor = true;
            // 
            // pictureBox17
            // 
            this.pictureBox17.Image = global::Presentaion_Layer.Properties.Resources.Person_32;
            this.pictureBox17.Location = new System.Drawing.Point(203, 81);
            this.pictureBox17.Name = "pictureBox17";
            this.pictureBox17.Size = new System.Drawing.Size(25, 23);
            this.pictureBox17.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox17.TabIndex = 31;
            this.pictureBox17.TabStop = false;
            // 
            // pictureBox16
            // 
            this.pictureBox16.Image = global::Presentaion_Layer.Properties.Resources.Password_32;
            this.pictureBox16.Location = new System.Drawing.Point(203, 200);
            this.pictureBox16.Name = "pictureBox16";
            this.pictureBox16.Size = new System.Drawing.Size(25, 23);
            this.pictureBox16.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox16.TabIndex = 30;
            this.pictureBox16.TabStop = false;
            // 
            // pictureBox15
            // 
            this.pictureBox15.Image = global::Presentaion_Layer.Properties.Resources.Password_32;
            this.pictureBox15.Location = new System.Drawing.Point(203, 260);
            this.pictureBox15.Name = "pictureBox15";
            this.pictureBox15.Size = new System.Drawing.Size(25, 23);
            this.pictureBox15.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox15.TabIndex = 29;
            this.pictureBox15.TabStop = false;
            // 
            // pictureBox13
            // 
            this.pictureBox13.Image = global::Presentaion_Layer.Properties.Resources.Person_32;
            this.pictureBox13.Location = new System.Drawing.Point(203, 147);
            this.pictureBox13.Name = "pictureBox13";
            this.pictureBox13.Size = new System.Drawing.Size(25, 23);
            this.pictureBox13.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox13.TabIndex = 27;
            this.pictureBox13.TabStop = false;
            // 
            // cbisactive
            // 
            this.cbisactive.AutoSize = true;
            this.cbisactive.Location = new System.Drawing.Point(328, 318);
            this.cbisactive.Name = "cbisactive";
            this.cbisactive.Size = new System.Drawing.Size(76, 20);
            this.cbisactive.TabIndex = 26;
            this.cbisactive.Text = "IsActive";
            this.cbisactive.UseVisualStyleBackColor = true;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(30, 200);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(132, 22);
            this.label9.TabIndex = 25;
            this.label9.Text = "User Password";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(6, 259);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(156, 22);
            this.label8.TabIndex = 24;
            this.label8.Text = "Confirm Password";
            // 
            // txtuserpassword
            // 
            this.txtuserpassword.Location = new System.Drawing.Point(243, 202);
            this.txtuserpassword.Name = "txtuserpassword";
            this.txtuserpassword.Size = new System.Drawing.Size(161, 22);
            this.txtuserpassword.TabIndex = 23;
            // 
            // txtconfirmuserpassword
            // 
            this.txtconfirmuserpassword.Location = new System.Drawing.Point(243, 261);
            this.txtconfirmuserpassword.Name = "txtconfirmuserpassword";
            this.txtconfirmuserpassword.Size = new System.Drawing.Size(161, 22);
            this.txtconfirmuserpassword.TabIndex = 22;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(62, 145);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(100, 22);
            this.label7.TabIndex = 21;
            this.label7.Text = "User Name";
            // 
            // lbluserid
            // 
            this.lbluserid.AutoSize = true;
            this.lbluserid.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbluserid.Location = new System.Drawing.Point(239, 81);
            this.lbluserid.Name = "lbluserid";
            this.lbluserid.Size = new System.Drawing.Size(40, 22);
            this.lbluserid.TabIndex = 18;
            this.lbluserid.Text = "N\\A";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(92, 81);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(70, 22);
            this.label3.TabIndex = 16;
            this.label3.Text = "User ID";
            // 
            // txtusername
            // 
            this.txtusername.Location = new System.Drawing.Point(243, 147);
            this.txtusername.Name = "txtusername";
            this.txtusername.Size = new System.Drawing.Size(161, 22);
            this.txtusername.TabIndex = 15;
            // 
            // btnsave
            // 
            this.btnsave.Location = new System.Drawing.Point(770, 620);
            this.btnsave.Name = "btnsave";
            this.btnsave.Size = new System.Drawing.Size(74, 34);
            this.btnsave.TabIndex = 7;
            this.btnsave.Text = "Save";
            this.btnsave.UseVisualStyleBackColor = true;
            this.btnsave.Click += new System.EventHandler(this.btnsave_Click);
            // 
            // btnclose
            // 
            this.btnclose.Location = new System.Drawing.Point(642, 620);
            this.btnclose.Name = "btnclose";
            this.btnclose.Size = new System.Drawing.Size(76, 34);
            this.btnclose.TabIndex = 8;
            this.btnclose.Text = "Close";
            this.btnclose.UseVisualStyleBackColor = true;
            this.btnclose.Click += new System.EventHandler(this.btnclose_Click);
            // 
            // pictureBox11
            // 
            this.pictureBox11.Image = global::Presentaion_Layer.Properties.Resources.SearchPerson;
            this.pictureBox11.Location = new System.Drawing.Point(754, 630);
            this.pictureBox11.Name = "pictureBox11";
            this.pictureBox11.Size = new System.Drawing.Size(21, 22);
            this.pictureBox11.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox11.TabIndex = 6;
            this.pictureBox11.TabStop = false;
            // 
            // AddUserControl
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.pictureBox11);
            this.Controls.Add(this.btnclose);
            this.Controls.Add(this.tabControl1);
            this.Controls.Add(this.btnsave);
            this.Name = "AddUserControl";
            this.Size = new System.Drawing.Size(897, 656);
            this.Load += new System.EventHandler(this.AddUserControl_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbimage)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox9)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.tabControl1.ResumeLayout(false);
            this.tppersonal.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox12)).EndInit();
            this.gb.ResumeLayout(false);
            this.gb.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.tplogin.ResumeLayout(false);
            this.tplogin.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox17)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox16)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox15)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox13)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox11)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.DateTimePicker dateTimePicker1;
        private System.Windows.Forms.PictureBox pbimage;
        private System.Windows.Forms.ComboBox cmbcountry;
        private System.Windows.Forms.PictureBox pictureBox9;
        private System.Windows.Forms.PictureBox pb;
        private System.Windows.Forms.PictureBox pictureBox7;
        private System.Windows.Forms.PictureBox pictureBox6;
        private System.Windows.Forms.PictureBox pictureBox5;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.TextBox txtphone;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label lblc;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtaddress;
        private System.Windows.Forms.RadioButton rdfemele;
        private System.Windows.Forms.RadioButton rdmale;
        private System.Windows.Forms.TextBox txtemail;
        private System.Windows.Forms.TextBox txtnationalno;
        private System.Windows.Forms.Label lbllast;
        private System.Windows.Forms.Label lblthird;
        private System.Windows.Forms.Label lblsec;
        private System.Windows.Forms.Label lblfirst;
        private System.Windows.Forms.TextBox txtlast;
        private System.Windows.Forms.TextBox txtthird;
        private System.Windows.Forms.TextBox txtsec;
        private System.Windows.Forms.TextBox txtfirstname;
        private System.Windows.Forms.Label lbladdress;
        private System.Windows.Forms.Label lblemail;
        private System.Windows.Forms.Label lblGender;
        private System.Windows.Forms.Label lblNational;
        private System.Windows.Forms.Label lblname;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tppersonal;
        private System.Windows.Forms.TabPage tplogin;
        private System.Windows.Forms.GroupBox gb;
        private System.Windows.Forms.PictureBox pictureBox8;
        private System.Windows.Forms.ComboBox cmbfiltr;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.TextBox txtfilter;
        private System.Windows.Forms.Button btnsave;
        private System.Windows.Forms.Button btnnext;
        private System.Windows.Forms.PictureBox pictureBox12;
        private System.Windows.Forms.PictureBox pictureBox11;
        private System.Windows.Forms.Button btnclose;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox txtuserpassword;
        private System.Windows.Forms.TextBox txtconfirmuserpassword;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label lbluserid;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtusername;
        private System.Windows.Forms.PictureBox pictureBox17;
        private System.Windows.Forms.PictureBox pictureBox16;
        private System.Windows.Forms.PictureBox pictureBox15;
        private System.Windows.Forms.PictureBox pictureBox13;
        private System.Windows.Forms.CheckBox cbisactive;
    }
}
