﻿using Business_Layer;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Presentaion_Layer.Users
{
    public partial class AddUersForm: Form
    {
        public AddUersForm()
        {
            InitializeComponent();
        }

        private void addUserControl1_Load(object sender, EventArgs e)
        {
            
        }
    }
}
