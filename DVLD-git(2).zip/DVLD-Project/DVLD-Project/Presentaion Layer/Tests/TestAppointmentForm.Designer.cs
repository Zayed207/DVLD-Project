﻿namespace Presentaion_Layer.Tests
{
    partial class TestAppointmentForm
    {

        #region Windows Form Designer generated code

        #endregion

       // private ManageApplications.Controls.ctrlApplicationInfo22 ctrlApplicationInfo;
        private ManageApplications.Licenses.Controls.LicenseInfoControl LicenseInfoControl;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.PictureBox pbaddapoinment;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label lblTitle;
        private System.Windows.Forms.PictureBox pbphotooftest;
        private ManageApplications.Controls.ApplicationInfoControl ApplicationInfoControl;
        private ManageApplications.Licenses.Controls.LicenseInfoControl ctrlLicenseInfo2;
    }
}