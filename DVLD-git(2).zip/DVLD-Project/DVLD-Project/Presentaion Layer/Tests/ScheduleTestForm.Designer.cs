﻿namespace Presentaion_Layer.Tests
{
    partial class ScheduleTestForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.scheduleTestControl11 = new Presentaion_Layer.Tests.Controls.ScheduleTestControl1();
            this.button1 = new System.Windows.Forms.Button();
            this.cbRetakeTestInfo = new System.Windows.Forms.GroupBox();
            this.lblTotalFees = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.pictureBox9 = new System.Windows.Forms.PictureBox();
            this.lblRetakeAppFees = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.pictureBox6 = new System.Windows.Forms.PictureBox();
            this.pictureBox5 = new System.Windows.Forms.PictureBox();
            this.lblRetakeTestAppID = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.cbRetakeTestInfo.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox9)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).BeginInit();
            this.SuspendLayout();
            // 
            // scheduleTestControl11
            // 
            this.scheduleTestControl11.Location = new System.Drawing.Point(2, -11);
            this.scheduleTestControl11.Name = "scheduleTestControl11";
            this.scheduleTestControl11.Size = new System.Drawing.Size(605, 722);
            this.scheduleTestControl11.TabIndex = 0;
            this.scheduleTestControl11.Load += new System.EventHandler(this.scheduleTestControl11_Load);
            // 
            // button1
            // 
            this.button1.Image = global::Presentaion_Layer.Properties.Resources.Close_32;
            this.button1.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button1.Location = new System.Drawing.Point(481, 741);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(136, 36);
            this.button1.TabIndex = 1;
            this.button1.Text = "Close";
            this.button1.UseVisualStyleBackColor = true;
            // 
            // cbRetakeTestInfo
            // 
            this.cbRetakeTestInfo.Controls.Add(this.lblTotalFees);
            this.cbRetakeTestInfo.Controls.Add(this.label9);
            this.cbRetakeTestInfo.Controls.Add(this.pictureBox9);
            this.cbRetakeTestInfo.Controls.Add(this.lblRetakeAppFees);
            this.cbRetakeTestInfo.Controls.Add(this.label7);
            this.cbRetakeTestInfo.Controls.Add(this.pictureBox6);
            this.cbRetakeTestInfo.Controls.Add(this.pictureBox5);
            this.cbRetakeTestInfo.Controls.Add(this.lblRetakeTestAppID);
            this.cbRetakeTestInfo.Controls.Add(this.label4);
            this.cbRetakeTestInfo.Location = new System.Drawing.Point(12, 522);
            this.cbRetakeTestInfo.Name = "cbRetakeTestInfo";
            this.cbRetakeTestInfo.Size = new System.Drawing.Size(580, 115);
            this.cbRetakeTestInfo.TabIndex = 191;
            this.cbRetakeTestInfo.TabStop = false;
            this.cbRetakeTestInfo.Text = "Retake Test Info";
            // 
            // lblTotalFees
            // 
            this.lblTotalFees.AutoSize = true;
            this.lblTotalFees.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTotalFees.Location = new System.Drawing.Point(446, 40);
            this.lblTotalFees.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.lblTotalFees.Name = "lblTotalFees";
            this.lblTotalFees.Size = new System.Drawing.Size(62, 25);
            this.lblTotalFees.TabIndex = 206;
            this.lblTotalFees.Text = "[$$$]";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(274, 40);
            this.label9.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(122, 25);
            this.label9.TabIndex = 204;
            this.label9.Text = "Total Fees:";
            // 
            // pictureBox9
            // 
            this.pictureBox9.Location = new System.Drawing.Point(406, 40);
            this.pictureBox9.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.pictureBox9.Name = "pictureBox9";
            this.pictureBox9.Size = new System.Drawing.Size(31, 26);
            this.pictureBox9.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox9.TabIndex = 205;
            this.pictureBox9.TabStop = false;
            // 
            // lblRetakeAppFees
            // 
            this.lblRetakeAppFees.AutoSize = true;
            this.lblRetakeAppFees.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblRetakeAppFees.Location = new System.Drawing.Point(180, 40);
            this.lblRetakeAppFees.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.lblRetakeAppFees.Name = "lblRetakeAppFees";
            this.lblRetakeAppFees.Size = new System.Drawing.Size(62, 25);
            this.lblRetakeAppFees.TabIndex = 203;
            this.lblRetakeAppFees.Text = "[$$$]";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(3, 40);
            this.label7.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(132, 25);
            this.label7.TabIndex = 201;
            this.label7.Text = "R.App.Fees:";
            // 
            // pictureBox6
            // 
            this.pictureBox6.Location = new System.Drawing.Point(140, 40);
            this.pictureBox6.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.pictureBox6.Name = "pictureBox6";
            this.pictureBox6.Size = new System.Drawing.Size(31, 26);
            this.pictureBox6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox6.TabIndex = 202;
            this.pictureBox6.TabStop = false;
            // 
            // pictureBox5
            // 
            this.pictureBox5.Location = new System.Drawing.Point(140, 76);
            this.pictureBox5.Name = "pictureBox5";
            this.pictureBox5.Size = new System.Drawing.Size(31, 26);
            this.pictureBox5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox5.TabIndex = 200;
            this.pictureBox5.TabStop = false;
            // 
            // lblRetakeTestAppID
            // 
            this.lblRetakeTestAppID.AutoSize = true;
            this.lblRetakeTestAppID.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblRetakeTestAppID.Location = new System.Drawing.Point(192, 76);
            this.lblRetakeTestAppID.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.lblRetakeTestAppID.Name = "lblRetakeTestAppID";
            this.lblRetakeTestAppID.Size = new System.Drawing.Size(50, 25);
            this.lblRetakeTestAppID.TabIndex = 199;
            this.lblRetakeTestAppID.Text = "[??]";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(-2, 76);
            this.label4.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(147, 25);
            this.label4.TabIndex = 198;
            this.label4.Text = "R.Test.App.ID";
            // 
            // ScheduleTestForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(619, 723);
            this.Controls.Add(this.cbRetakeTestInfo);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.scheduleTestControl11);
            this.Name = "ScheduleTestForm";
            this.Text = "ScheduleTestForm";
            this.Load += new System.EventHandler(this.ScheduleTestForm_Load);
            this.cbRetakeTestInfo.ResumeLayout(false);
            this.cbRetakeTestInfo.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox9)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private Presentaion_Layer.Tests. Controls.ScheduleTestControl1  scheduleTestControl11;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.GroupBox cbRetakeTestInfo;
        private System.Windows.Forms.Label lblTotalFees;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.PictureBox pictureBox9;
        private System.Windows.Forms.Label lblRetakeAppFees;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.PictureBox pictureBox6;
        private System.Windows.Forms.PictureBox pictureBox5;
        private System.Windows.Forms.Label lblRetakeTestAppID;
        private System.Windows.Forms.Label label4;
    }
}