﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Presentaion_Layer
{
    public partial class AddForm: Form
    {
        public AddForm()
        {
            InitializeComponent();
        }

        private void person1_Load(object sender, EventArgs e)
        {

        }
    }
}
