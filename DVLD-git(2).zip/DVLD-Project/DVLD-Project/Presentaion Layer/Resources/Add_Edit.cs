﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Presentaion_Layer.PeopleControl
{
    [System.ComponentModel.ToolboxItem(true)]
    public partial class Add_Edit: UserControl
    {
        public Add_Edit()
        {
            InitializeComponent();
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void Add_Edit_Load(object sender, EventArgs e)
        {

        }

        private void txtnational_TextChanged(object sender, EventArgs e)
        {

        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }
    }
}
